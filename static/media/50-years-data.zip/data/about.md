# Commission_Regulations_Directives.csv

The file includes all legislation adopted by the Commission between
1970 and 2018 in the field of environmental protection.

These figures do not include environmental product regulations adopted
under the energy article, such as ecodesign measures.

The file was compiled from two Eur-Lex queries, one for regulations
and one for directives.

Query 1:

Domain: EU law and related documents, Subdomain: Legislation, Author:
European Commission, Type of act: All regulations, Date: All dates,
From: 01/01/1970, To: 31/12/2018, Directory code, 1st level:
Environment, consumers and health protection, Directory code, 2nd
level: Environment, Search language: English.

Query 2:

Domain: EU law and related documents, Subdomain: Legislation, Author:
European Commission, Type of act: All Directives, Date: All dates,
From: 01/01/1970, To: 31/12/2018, Directory code, 1st level:
Environment, consumers and health protection, Directory code, 2nd
level: Environment, Search language: English.


# Environment_legislation.csv

The Data in this file is from EurLex; it has been slightly cleaned up
to get rid of encoding issues. The query was as follows:

Query: DTS_SUBDOM = LEGISLATION AND CC_2_CODED = 1510 AND (AU_CODED =
CONSIL OR CONS OR CS) AND (DD >= 01/01/1970 <= 31/12/2018), Search
language: English.

The file is a complete list of all environmental policies (directives,
decisions, regulations) with the involvement of the Council ever
adopted until 31 December 2018.


# Environment_legislation.RData

This R data file is identical with Environment_legislation.csv.

Type

> load('Environment_legislation.RData')

to load.


# environment_legislation.R and commission_directives_and_regulations.R

These files contain the R code to produce plots showing the number
of the respective legal acts adopted per year.

